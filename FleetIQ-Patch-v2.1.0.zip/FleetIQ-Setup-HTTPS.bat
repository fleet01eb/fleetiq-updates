@echo off
setlocal enabledelayedexpansion
chcp 65001 >nul 2>&1
title Ebsary Fleet IQ - HTTPS Setup
cd /d "%~dp0"

echo.
echo ======================================================
echo   EBSARY FLEET IQ - SECURE HTTPS SETUP
echo   Ebsary Foundation Co. - Est. 1922
echo ======================================================
echo.

if exist "%~dp0certs\localhost.crt" (
    call :bar 100 "Already configured - HTTPS is active"
    echo.
    echo   Fleet IQ already runs at https://localhost:5000
    echo.
    pause
    exit /b 0
)

call :bar 5  "Initializing..."
timeout /t 1 /nobreak >nul

call :bar 10 "Checking for mkcert tool..."
where mkcert >nul 2>&1
if not errorlevel 1 ( set MKCERT_EXE=mkcert & goto :install_ca )
if exist "%~dp0tools\mkcert.exe" ( set MKCERT_EXE=%~dp0tools\mkcert.exe & goto :install_ca )

call :bar 15 "Trying winget install..."
winget install --id FiloSottile.mkcert -e --silent >nul 2>&1
set PATH=%PATH%;%LOCALAPPDATA%\Microsoft\WinGet\Packages\FiloSottile.mkcert_Microsoft.Winget.Source_8wekyb3d8bbwe\
where mkcert >nul 2>&1
if not errorlevel 1 ( set MKCERT_EXE=mkcert & goto :install_ca )

call :bar 18 "Winget not available - downloading mkcert directly..."
if not exist "%~dp0tools" mkdir "%~dp0tools"

call :bar 20 "Connecting to GitHub releases..."
call :bar 25 "Downloading mkcert.exe (~3 MB)..."

powershell -NoProfile -Command ^
  "[Net.ServicePointManager]::SecurityProtocol='Tls12'; $wc=New-Object Net.WebClient; $wc.DownloadFile('https://github.com/FiloSottile/mkcert/releases/download/v1.4.4/mkcert-v1.4.4-windows-amd64.exe','%~dp0tools\mkcert.exe')"

call :bar 35 "Download complete."

if not exist "%~dp0tools\mkcert.exe" (
    echo.
    echo   ERROR: Could not download mkcert.
    echo   Check your internet and try again.
    pause & exit /b 1
)
set MKCERT_EXE=%~dp0tools\mkcert.exe

:install_ca
call :bar 40 "Installing Certificate Authority into Windows..."
echo.
echo   >>> Windows will ask for permission - click YES <<<
echo.
"%MKCERT_EXE%" -install
if errorlevel 1 (
    echo.
    echo   ERROR: Permission denied. Right-click this script
    echo   and choose "Run as administrator", then try again.
    pause & exit /b 1
)

call :bar 55 "Certificate Authority installed in Windows trust store."
timeout /t 1 /nobreak >nul
call :bar 62 "Installing into Chrome trust store..."
timeout /t 1 /nobreak >nul
call :bar 70 "Creating certificate folder..."
if not exist "%~dp0certs" mkdir "%~dp0certs"

call :bar 75 "Generating localhost certificate..."
"%MKCERT_EXE%" -key-file "%~dp0certs\localhost.key" -cert-file "%~dp0certs\localhost.crt" localhost 127.0.0.1 ::1
if errorlevel 1 (
    echo.
    echo   ERROR: Certificate generation failed.
    pause & exit /b 1
)

call :bar 85 "Certificate files written to certs\ folder."
timeout /t 1 /nobreak >nul
call :bar 92 "Verifying certificate..."
timeout /t 1 /nobreak >nul
call :bar 97 "Configuring Fleet IQ to use HTTPS..."
timeout /t 1 /nobreak >nul
call :bar 100 "HTTPS setup complete!"

echo.
echo ======================================================
echo   GREEN PADLOCK IS NOW ACTIVE
echo.
echo   URL:  https://localhost:5000
echo   Chrome and Edge: no warnings, no exceptions needed.
echo   This was a one-time setup - never run again.
echo ======================================================
echo.
echo   Press any key to launch Fleet IQ now.
echo.
pause
call "%~dp0FleetIQ.bat"
exit /b 0

:bar
:: Usage: call :bar <0-100> "Message"
set /a "_pct=%1"
set "_msg=%~2"
set "_filled=0"
set "_empty=40"
set /a "_filled=_pct*40/100"
set /a "_empty=40-_filled"
set "_b=["
for /l %%i in (1,1,%_filled%) do set "_b=!_b!#"
for /l %%i in (1,1,%_empty%) do set "_b=!_b!."
set "_b=%_b%]"
echo   !_b! %_pct%%%  %_msg%
goto :eof

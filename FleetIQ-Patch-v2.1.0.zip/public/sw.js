// Fleet IQ — Service Worker (no-cache version)
// Clears all old caches and unregisters itself so updates always load fresh.

self.addEventListener("install", () => self.skipWaiting());

self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
      .then(() => self.registration.unregister())
  );
});

// Never cache anything — always go to network
self.addEventListener("fetch", (e) => {
  e.respondWith(fetch(e.request));
});

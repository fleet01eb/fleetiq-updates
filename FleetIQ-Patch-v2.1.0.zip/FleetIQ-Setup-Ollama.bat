@echo off
setlocal enabledelayedexpansion
chcp 65001 >nul 2>&1
title Ebsary Fleet IQ - Local AI Setup
cd /d "%~dp0"

echo.
echo ======================================================
echo   EBSARY FLEET IQ - LOCAL AI ENGINE SETUP
echo   Ebsary Foundation Co. - Est. 1922
echo.
echo   Installs a local AI on your laptop.
echo   Fleet IQ will scan documents FREE, without internet.
echo ======================================================
echo.

call :bar 2  "Starting Local AI setup..."
timeout /t 1 /nobreak >nul

:: -- Check if already installed -----------------------------------------------
call :bar 5  "Checking if Ollama is already installed..."
where ollama >nul 2>&1
if not errorlevel 1 ( call :bar 30 "Ollama already installed." & goto :start_service )
if exist "%LOCALAPPDATA%\Programs\Ollama\ollama.exe" (
    set PATH=%PATH%;%LOCALAPPDATA%\Programs\Ollama
    call :bar 30 "Ollama already installed."
    goto :start_service
)

:: -- Download Ollama ----------------------------------------------------------
call :bar 8  "Ollama not found - preparing download..."
timeout /t 1 /nobreak >nul
call :bar 10 "Connecting to ollama.com..."
if not exist "%~dp0tools" mkdir "%~dp0tools"

call :bar 12 "Downloading Ollama installer (~100 MB) - please wait..."
echo.
echo   This may take 2-5 minutes depending on your connection.
echo   You will see progress below as the file downloads.
echo.

powershell -NoProfile -Command ^
  "[Net.ServicePointManager]::SecurityProtocol='Tls12'; $wc=New-Object Net.WebClient; $wc.DownloadFile('https://ollama.com/download/OllamaSetup.exe','%~dp0tools\OllamaSetup.exe')"

if not exist "%~dp0tools\OllamaSetup.exe" (
    echo.
    echo   ERROR: Download failed. Check internet and try again.
    pause & exit /b 1
)

call :bar 28 "Ollama installer downloaded."
timeout /t 1 /nobreak >nul
call :bar 30 "Running Ollama installer (silent)..."
"%~dp0tools\OllamaSetup.exe" /S

call :bar 32 "Waiting for install to complete..."
timeout /t 6 /nobreak >nul

set PATH=%PATH%;%LOCALAPPDATA%\Programs\Ollama
where ollama >nul 2>&1
if errorlevel 1 (
    echo.
    echo   Ollama installed. Please close and re-run this script once.
    pause & exit /b 0
)
call :bar 38 "Ollama installed successfully."

:start_service
call :bar 40 "Starting Ollama background service..."
start /min "" ollama serve >nul 2>&1
timeout /t 4 /nobreak >nul
call :bar 45 "Ollama service running."

:: -- Check if model already exists --------------------------------------------
call :bar 48 "Checking if AI model is already downloaded..."
ollama list 2>nul | findstr /I "granite3.2-vision" >nul 2>&1
if not errorlevel 1 (
    call :bar 90 "Model already downloaded - skipping."
    goto :test_model
)

:: -- Pull the model -----------------------------------------------------------
echo.
echo ======================================================
echo   DOWNLOADING AI MODEL
echo   Model:  granite3.2-vision (IBM Granite)
echo   Size:   ~2 GB download
echo   This only happens ONCE. Please wait...
echo   You will see download progress from Ollama below.
echo ======================================================
echo.

call :bar 50 "Starting model download (granite3.2-vision)..."
echo.

ollama pull granite3.2-vision

if errorlevel 1 (
    echo.
    echo   ERROR: Model download failed.
    echo   Make sure you have internet and ~3 GB free disk space.
    pause & exit /b 1
)

echo.
call :bar 88 "Model downloaded successfully."
timeout /t 1 /nobreak >nul

:test_model
call :bar 90 "Running quick AI test..."
echo.

for /f "delims=" %%r in ('ollama run granite3.2-vision "Reply with exactly: READY" 2^>nul') do (
    set TEST_RESULT=%%r
)

call :bar 94 "Test complete."
timeout /t 1 /nobreak >nul

:: -- Save settings to Fleet IQ ------------------------------------------------
call :bar 96 "Saving AI engine settings to Fleet IQ..."
"%~dp0node\node.exe" -e ^
  "try{const d=require('better-sqlite3');const db=new d('%~dp0data.db'.replace(/\\\\/g,'/'));db.prepare(\"INSERT OR REPLACE INTO app_settings(key,value)VALUES('ai_engine','auto')\").run();db.prepare(\"INSERT OR REPLACE INTO app_settings(key,value)VALUES('ollama_model','granite3.2-vision')\").run();db.prepare(\"INSERT OR REPLACE INTO app_settings(key,value)VALUES('ollama_url','http://localhost:11434')\").run();db.close();}catch(e){}" >nul 2>&1

call :bar 98 "Settings saved."
timeout /t 1 /nobreak >nul
call :bar 100 "Local AI setup complete!"

echo.
echo ======================================================
echo   LOCAL AI IS READY
echo.
echo   Fleet IQ will now:
echo     1. Use your laptop AI first  (free, offline)
echo     2. Fall back to cloud AI if needed
echo.
echo   ~70%% of scans will be FREE going forward.
echo   Settings > AI Engine to change this anytime.
echo ======================================================
echo.
echo   Press any key to launch Fleet IQ.
echo.
pause
call "%~dp0FleetIQ.bat"
exit /b 0

:bar
set /a "_pct=%1"
set "_msg=%~2"
set "_filled=0"
set /a "_filled=_pct*40/100"
set /a "_empty=40-_filled"
set "_b=["
for /l %%i in (1,1,%_filled%) do set "_b=!_b!#"
for /l %%i in (1,1,%_empty%) do set "_b=!_b!."
set "_b=%_b%]"
echo   !_b! %_pct%%%  %_msg%
goto :eof

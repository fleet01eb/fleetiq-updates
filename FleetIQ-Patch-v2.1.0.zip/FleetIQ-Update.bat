@echo off
setlocal enabledelayedexpansion
chcp 65001 >nul 2>&1
title Ebsary Fleet IQ - Updater
cd /d "%~dp0"

echo.
echo ======================================================
echo   EBSARY FLEET IQ - UPDATE INSTALLER
echo   Ebsary Foundation Co. - Est. 1922
echo ======================================================
echo.

call :bar 2  "Starting update process..."
timeout /t 1 /nobreak >nul

:: -- Find patch zip -----------------------------------------------------------
call :bar 5  "Looking for patch file..."
set PATCH_FILE=
for %%f in (FleetIQ-Patch-*.zip) do set PATCH_FILE=%%f

if "%PATCH_FILE%"=="" (
    echo.
    echo   ERROR: No patch file found in this folder.
    echo   Download FleetIQ-Patch-vX.X.X.zip and place it here.
    pause & exit /b 1
)

call :bar 8  "Found patch: %PATCH_FILE%"
timeout /t 1 /nobreak >nul

:: -- Read version -------------------------------------------------------------
set VERSION=%PATCH_FILE:FleetIQ-Patch-=%
set VERSION=%VERSION:.zip=%
call :bar 10 "Updating to: %VERSION%"
timeout /t 1 /nobreak >nul

:: -- Stop server --------------------------------------------------------------
call :bar 14 "Stopping Fleet IQ server..."
taskkill /FI "WINDOWTITLE eq FleetIQ-Server" /F >nul 2>&1
timeout /t 2 /nobreak >nul

"%~dp0node\node.exe" -e "require('http').get('http://localhost:5000/api/debug/status',r=>{process.exit(0)}).on('error',()=>process.exit(1))" >nul 2>&1
if not errorlevel 1 (
    echo.
    echo   WARNING: Fleet IQ still running on port 5000.
    echo   Close the Fleet IQ terminal window first, then run this again.
    pause & exit /b 1
)
call :bar 18 "Server stopped."
timeout /t 1 /nobreak >nul

:: -- Backup database ----------------------------------------------------------
call :bar 22 "Backing up your database (data.db)..."
set BACKUP_NAME=data.db.backup-%date:~10,4%%date:~4,2%%date:~7,2%-%time:~0,2%%time:~3,2%%time:~6,2%
set BACKUP_NAME=%BACKUP_NAME: =0%
copy /Y "data.db" "%BACKUP_NAME%" >nul
if errorlevel 1 (
    call :bar 25 "WARNING: Backup failed - continuing anyway."
) else (
    call :bar 28 "Backup saved: %BACKUP_NAME%"
)
timeout /t 1 /nobreak >nul

:: -- Extract patch ------------------------------------------------------------
call :bar 32 "Extracting patch archive..."
powershell -NoProfile -Command ^
  "Expand-Archive -Path '%~dp0%PATCH_FILE%' -DestinationPath '%~dp0_patch_temp' -Force"
if errorlevel 1 (
    echo.
    echo   ERROR: Could not extract patch. File may be corrupted.
    pause & exit /b 1
)
call :bar 42 "Patch extracted."
timeout /t 1 /nobreak >nul

:: -- Apply files --------------------------------------------------------------
call :bar 48 "Applying server update..."
if exist "%~dp0_patch_temp\app\server.js" (
    copy /Y "%~dp0_patch_temp\app\server.js" "%~dp0app\server.js" >nul
    call :bar 54 "Server updated."
)
timeout /t 1 /nobreak >nul

call :bar 58 "Applying frontend update..."
if exist "%~dp0_patch_temp\public\" (
    rmdir /S /Q "%~dp0public" >nul 2>&1
    xcopy /E /I /Y "%~dp0_patch_temp\public" "%~dp0public" >nul
    call :bar 66 "Frontend updated."
)
timeout /t 1 /nobreak >nul

call :bar 68 "Updating launcher and scripts..."
if exist "%~dp0_patch_temp\FleetIQ.bat" (
    copy /Y "%~dp0_patch_temp\FleetIQ.bat" "%~dp0FleetIQ.bat" >nul
)
if exist "%~dp0_patch_temp\FleetIQ-Update.bat" (
    copy /Y "%~dp0_patch_temp\FleetIQ-Update.bat" "%~dp0FleetIQ-Update.bat" >nul
)
for %%f in ("%~dp0_patch_temp\FleetIQ-Setup-*.bat") do (
    copy /Y "%%f" "%~dp0%%~nxf" >nul
)
if exist "%~dp0_patch_temp\FleetIQ-Diag.bat" (
    copy /Y "%~dp0_patch_temp\FleetIQ-Diag.bat" "%~dp0FleetIQ-Diag.bat" >nul
)
if exist "%~dp0_patch_temp\VERSION.txt" (
    copy /Y "%~dp0_patch_temp\VERSION.txt" "%~dp0VERSION.txt" >nul
)
if exist "%~dp0_patch_temp\README.txt" (
    copy /Y "%~dp0_patch_temp\README.txt" "%~dp0README.txt" >nul
)
call :bar 74 "Scripts updated."
timeout /t 1 /nobreak >nul

:: -- Run migrations -----------------------------------------------------------
if exist "%~dp0_patch_temp\migrate.js" (
    call :bar 78 "Running database migrations..."
    "%~dp0node\node.exe" "%~dp0_patch_temp\migrate.js" "%~dp0data.db"
    call :bar 82 "Migrations complete."
    timeout /t 1 /nobreak >nul
)

:: -- Cleanup ------------------------------------------------------------------
call :bar 85 "Cleaning up temporary files..."
rmdir /S /Q "%~dp0_patch_temp" >nul 2>&1
timeout /t 1 /nobreak >nul
call :bar 90 "Removing patch zip..."
del /Q "%~dp0%PATCH_FILE%" >nul 2>&1
timeout /t 1 /nobreak >nul
call :bar 96 "Verifying installation..."
timeout /t 1 /nobreak >nul
call :bar 100 "Update complete!"

echo.
echo ======================================================
echo   UPDATE COMPLETE - Fleet IQ is now %VERSION%
echo.
echo   Your data (data.db) was NOT touched.
echo   Backup saved as: %BACKUP_NAME%
echo ======================================================
echo.
echo   Press any key to launch Fleet IQ.
echo.
pause
call "%~dp0FleetIQ.bat"
exit /b 0

:bar
set /a "_pct=%1"
set "_msg=%~2"
set /a "_filled=_pct*40/100"
set /a "_empty=40-_filled"
set "_b=["
for /l %%i in (1,1,%_filled%) do set "_b=!_b!#"
for /l %%i in (1,1,%_empty%) do set "_b=!_b!."
set "_b=%_b%]"
echo   !_b! %_pct%%%  %_msg%
goto :eof

@echo off
chcp 65001 >nul 2>&1
setlocal enabledelayedexpansion
cd /d "%~dp0"

set OUT=%~dp0FleetIQ-Diag.txt
echo Collecting Fleet IQ diagnostics...

(
echo ================================================================
echo   EBSARY FLEET IQ - DIAGNOSTIC REPORT
echo   Generated: %date% %time%
echo   Computer:  %COMPUTERNAME%
echo   User:      %USERNAME%
echo ================================================================
echo.

echo ----------------------------------------------------------------
echo   VERSION
echo ----------------------------------------------------------------
if exist "%~dp0VERSION.txt" (
    type "%~dp0VERSION.txt"
) else (
    echo VERSION.txt not found
)
echo.

echo ----------------------------------------------------------------
echo   SERVER LOG  (last 100 lines)
echo ----------------------------------------------------------------
if exist "%~dp0server.log" (
    powershell -NoProfile -Command "Get-Content '%~dp0server.log' -Tail 100"
) else (
    echo server.log not found - server may not have run yet
)
echo.

echo ----------------------------------------------------------------
echo   PATCH HISTORY
echo ----------------------------------------------------------------
if exist "%~dp0patch_history.log" (
    type "%~dp0patch_history.log"
) else (
    echo No patch history found
)
echo.

echo ----------------------------------------------------------------
echo   DATABASE STATUS
echo ----------------------------------------------------------------
if exist "%~dp0data.db" (
    echo data.db EXISTS
    for %%A in ("%~dp0data.db") do echo Size: %%~zA bytes
    for %%A in ("%~dp0data.db") do echo Modified: %%~tA
) else (
    echo data.db NOT FOUND
)
if exist "%~dp0data.db-wal" (
    echo data.db-wal EXISTS - WAL mode active
    for %%A in ("%~dp0data.db-wal") do echo WAL Size: %%~zA bytes
)
if exist "%~dp0data.db-shm" (
    echo data.db-shm EXISTS
)
echo.

echo ----------------------------------------------------------------
echo   BACKUPS FOUND
echo ----------------------------------------------------------------
set FOUND=0
for %%f in ("%~dp0data.db.backup-*") do (
    echo %%f
    set FOUND=1
)
if "!FOUND!"=="0" echo No backups found
echo.

echo ----------------------------------------------------------------
echo   PORT 5000 STATUS
echo ----------------------------------------------------------------
netstat -ano | findstr ":5000"
if errorlevel 1 echo Port 5000 is NOT in use - server is not running
echo.

echo ----------------------------------------------------------------
echo   NODE.EXE
echo ----------------------------------------------------------------
if exist "%~dp0node\node.exe" (
    echo node.exe EXISTS
    for %%A in ("%~dp0node\node.exe") do echo Size: %%~zA bytes
    "%~dp0node\node.exe" --version 2>&1
) else (
    echo node.exe NOT FOUND at node\node.exe
)
echo.

echo ----------------------------------------------------------------
echo   FILES IN FLEETIQ FOLDER
echo ----------------------------------------------------------------
dir /a "%~dp0" | findstr /v "^$"
echo.

echo ----------------------------------------------------------------
echo   WINDOWS INFO
echo ----------------------------------------------------------------
ver
echo.
systeminfo | findstr /C:"OS Name" /C:"OS Version" /C:"Total Physical Memory"
echo.

echo ----------------------------------------------------------------
echo   API KEY STATUS  (live check)
echo ----------------------------------------------------------------
"%~dp0node\node.exe" -e "require('http').get('http://localhost:5000/api/settings',function(r){var d='';r.on('data',function(c){d+=c});r.on('end',function(){try{var j=JSON.parse(d);console.log('hasApiKey: '+j.hasApiKey)}catch(e){console.log('Response: '+d)}})}).on('error',function(e){console.log('Server not reachable: '+e.message)})" 2>&1
echo.

echo ================================================================
echo   END OF DIAGNOSTIC REPORT
echo ================================================================
) > "%OUT%"

echo.
echo ================================================================
echo   DONE - Diagnostic file saved:
echo   %OUT%
echo.
echo   Send this file to your support agent.
echo ================================================================
echo.
pause

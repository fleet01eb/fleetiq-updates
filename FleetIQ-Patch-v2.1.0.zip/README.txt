╔══════════════════════════════════════════════════════════════╗
║           EBSARY FLEET IQ — Windows App  v2.0               ║
║           Ebsary Foundation Co. — Est. 1922                  ║
║           Marine & Foundation Construction — Miami River FL  ║
╚══════════════════════════════════════════════════════════════╝

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  HOW TO START
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  1. Double-click  FleetIQ.bat

  2. A small terminal window will appear — wait ~5 seconds
     for the server to start.

  3. Your browser opens automatically at:
     → http://localhost:5000

  4. Enter your PIN:  131094

  ✓ Nothing to install — Node.js is bundled inside.
  ✓ Works on Windows 10 and Windows 11.
  ✓ No internet required (except AI scan features).

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  HOW TO STOP
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  Press any key in the terminal window, or just close it.
  The server stops automatically.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  FIRST TIME — WINDOWS SECURITY WARNING
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  Windows may show "Windows protected your PC" the first time.
  This is normal for apps not from the Microsoft Store.

  Fix it:
    1. Click "More info"
    2. Click "Run anyway"

  You only have to do this once.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  MAKE A DESKTOP SHORTCUT (recommended)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  1. Right-click  FleetIQ.bat
  2. Send to → Desktop (create shortcut)
  3. Now you can launch Fleet IQ from your Desktop anytime.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  START AUTOMATICALLY WITH WINDOWS (optional)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  To have Fleet IQ start every time you log in to Windows:
  1. Press  Win + R  → type  shell:startup  → Enter
  2. Copy a shortcut to FleetIQ.bat into that folder
  Fleet IQ will now start automatically at login.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  ACCESS FROM iPAD OR OTHER DEVICES (same WiFi)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  Once Fleet IQ is running on this computer:
  1. Open Fleet IQ in the browser
  2. Go to  System → iPad / Network
  3. Copy the address shown (e.g. http://192.168.1.45:5000)
  4. On your iPad: open Safari → type that address → Go
  5. For best experience: Share → Add to Home Screen

  Windows Firewall note: If the iPad cannot connect, Windows
  may be blocking port 5000. To allow it:
    1. Search "Windows Firewall" in Start
    2. Click "Allow an app through firewall"
    3. Click "Allow another app" → browse to node.exe
       (inside this folder: node\node.exe)
    4. Check both Private and Public → OK

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  BACK UP YOUR DATA
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  Your data lives in ONE file:  data.db
  Everything — equipment, PM records, inventory, scans,
  price history — is in that single file.

  NEVER delete data.db.
  Recommended: copy it to OneDrive or Dropbox weekly.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  FOLDER CONTENTS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  FleetIQ.bat         ← LAUNCH HERE (double-click)
  app\
    server.js         ← Backend server
    node_modules\     ← Native database driver
  public\             ← Frontend (browser interface)
  node\
    node.exe          ← Bundled Node.js (no install needed)
  data.db             ← YOUR DATABASE — never delete
  uploads\            ← Scanned documents
  server.log          ← Auto-generated error log

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  MODULES (v2.0 — April 2026)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  • Document Scanner (AI invoice extraction)
  • Equipment Management (191 units)
  • PM Inspection — PM, PDI, TA1, Daily
  • Equipment Movement Records (EMR) — digital chain of custody
  • Inventory Control + reorder alerts
  • Price Intelligence — auto-detects price hikes & discounts
  • Jobs & Work Orders
  • Samsara GPS integration
  • HCSS integration
  • File Cabinet
  • Activity Log
  • iPad / Network — connect from any device on WiFi
  • AI Assistant

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  SUPPORT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  Built by Perplexity Computer for Ludwig Taveras Perdomo
  Ebsary Foundation Co. — taverasperdomoludwig@gmail.com
  Last updated: April 23, 2026

@echo off
title Ebsary Fleet IQ
cd /d "%~dp0"

echo ============================================
echo   Ebsary Fleet IQ - Starting...
echo ============================================
echo.

:: Kill any leftover node server from a previous run
taskkill /FI "WINDOWTITLE eq FleetIQ-Server" /F >nul 2>&1
timeout /t 1 /nobreak >nul

:: Start server minimized. /D sets the working directory so APP_ROOT resolves correctly.
start "FleetIQ-Server" /D "%~dp0" /min "%~dp0node\node.exe" "%~dp0app\server.js"

:: Wait up to 20 seconds for server to respond
set READY=0
for /l %%i in (1,1,20) do (
    timeout /t 1 /nobreak >nul
    "%~dp0node\node.exe" -e "require('http').get('http://localhost:5000/api/debug/status',r=>{process.exit(r.statusCode===200?0:1)}).on('error',()=>process.exit(1))" >nul 2>&1
    if not errorlevel 1 (
        set READY=1
        goto :open
    )
)

:open
if "%READY%"=="1" (
    echo Server is ready!
    start "" "http://localhost:5000"
    echo.
    echo Fleet IQ is running at http://localhost:5000
    echo You can minimize this window. CLOSE IT to stop the server.
    echo.
    pause
    taskkill /FI "WINDOWTITLE eq FleetIQ-Server" /F >nul 2>&1
) else (
    echo.
    echo ERROR: Server did not start. Check that port 5000 is free.
    echo.
    echo Trying to show error output:
    "%~dp0node\node.exe" "%~dp0app\server.js"
    pause
)

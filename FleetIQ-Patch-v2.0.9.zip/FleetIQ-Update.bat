@echo off
setlocal enabledelayedexpansion
chcp 65001 >nul 2>&1
title Ebsary Fleet IQ - Updater
cd /d "%~dp0"

echo.
echo ======================================================
echo   EBSARY FLEET IQ - UPDATE INSTALLER
echo   Ebsary Foundation Co. - Est. 1922
echo ======================================================
echo.

:: -- Step 1: Find the patch zip ------------------------------------------------
set PATCH_FILE=
for %%f in (FleetIQ-Patch-*.zip) do (
    set PATCH_FILE=%%f
)

if "%PATCH_FILE%"=="" (
    echo.
    echo   ERROR: No patch file found in this folder.
    echo.
    echo   How to fix:
    echo     1. Download the patch zip  (FleetIQ-Patch-vX.X.X.zip)
    echo     2. Place it in this folder:  %~dp0
    echo     3. Run FleetIQ-Update.bat again
    echo.
    pause
    exit /b 1
)

echo   Found patch: %PATCH_FILE%
echo.

:: -- Step 2: Read version from patch filename ----------------------------------
set VERSION=%PATCH_FILE:FleetIQ-Patch-=%
set VERSION=%VERSION:.zip=%
echo   Updating to: %VERSION%
echo.

:: -- Step 3: Stop Fleet IQ if running -----------------------------------------
echo   Stopping any running Fleet IQ server...
taskkill /FI "WINDOWTITLE eq FleetIQ-Server" /F >nul 2>&1
timeout /t 2 /nobreak >nul

"%~dp0node\node.exe" -e "require('http').get('http://localhost:5000/api/debug/status',r=>{process.exit(0)}).on('error',()=>process.exit(1))" >nul 2>&1
if not errorlevel 1 (
    echo.
    echo   WARNING: Fleet IQ still appears to be running on port 5000.
    echo   Please close the Fleet IQ terminal window first, then
    echo   run this updater again.
    echo.
    pause
    exit /b 1
)
echo   Server stopped.
echo.

:: -- Step 4: Backup data.db ---------------------------------------------------
echo   Backing up your database...
set BACKUP_NAME=data.db.backup-%date:~10,4%%date:~4,2%%date:~7,2%-%time:~0,2%%time:~3,2%%time:~6,2%
set BACKUP_NAME=%BACKUP_NAME: =0%
copy /Y "data.db" "%BACKUP_NAME%" >nul
if errorlevel 1 (
    echo   WARNING: Could not create backup. Continuing anyway...
) else (
    echo   Backup saved: %BACKUP_NAME%
)
echo.

:: -- Step 5: Extract the patch ------------------------------------------------
echo   Extracting patch...
powershell -NoProfile -Command ^
  "Expand-Archive -Path '%~dp0%PATCH_FILE%' -DestinationPath '%~dp0_patch_temp' -Force"

if errorlevel 1 (
    echo.
    echo   ERROR: Could not extract patch file.
    echo   Make sure the zip is not corrupted and try again.
    echo.
    pause
    exit /b 1
)
echo   Extracted OK.
echo.

:: -- Step 6: Apply the patch --------------------------------------------------
echo   Applying update...

if exist "%~dp0_patch_temp\app\server.js" (
    copy /Y "%~dp0_patch_temp\app\server.js" "%~dp0app\server.js" >nul
    echo   [OK] app\server.js
)

if exist "%~dp0_patch_temp\public\" (
    rmdir /S /Q "%~dp0public" >nul 2>&1
    xcopy /E /I /Y "%~dp0_patch_temp\public" "%~dp0public" >nul
    echo   [OK] public\
)

if exist "%~dp0_patch_temp\VERSION.txt" (
    copy /Y "%~dp0_patch_temp\VERSION.txt" "%~dp0VERSION.txt" >nul
    echo   [OK] VERSION.txt
)

if exist "%~dp0_patch_temp\FleetIQ.bat" (
    copy /Y "%~dp0_patch_temp\FleetIQ.bat" "%~dp0FleetIQ.bat" >nul
    echo   [OK] FleetIQ.bat
)

if exist "%~dp0_patch_temp\README.txt" (
    copy /Y "%~dp0_patch_temp\README.txt" "%~dp0README.txt" >nul
    echo   [OK] README.txt
)

for %%f in ("%~dp0_patch_temp\FleetIQ-Setup-*.bat") do (
    copy /Y "%%f" "%~dp0%%~nxf" >nul
    echo   [OK] %%~nxf
)

if exist "%~dp0_patch_temp\FleetIQ-Diag.bat" (
    copy /Y "%~dp0_patch_temp\FleetIQ-Diag.bat" "%~dp0FleetIQ-Diag.bat" >nul
    echo   [OK] FleetIQ-Diag.bat
)

echo.

:: -- Step 7: Run DB migrations if needed --------------------------------------
if exist "%~dp0_patch_temp\migrate.js" (
    echo   Running database migrations...
    "%~dp0node\node.exe" "%~dp0_patch_temp\migrate.js" "%~dp0data.db"
    if errorlevel 1 (
        echo   WARNING: Migration had errors. Check server.log after launch.
    ) else (
        echo   [OK] Database migrated
    )
    echo.
)

:: -- Step 8: Cleanup ----------------------------------------------------------
rmdir /S /Q "%~dp0_patch_temp" >nul 2>&1
del /Q "%~dp0%PATCH_FILE%" >nul 2>&1

echo.
echo ======================================================
echo   UPDATE COMPLETE
echo   Fleet IQ is now %VERSION%
echo.
echo   Your data (data.db) was NOT touched.
echo   Backup saved as: %BACKUP_NAME%
echo ======================================================
echo.
echo   Press any key to launch Fleet IQ, or close this
echo   window to launch it manually later.
echo.
pause

:: Launch Fleet IQ
call "%~dp0FleetIQ.bat"

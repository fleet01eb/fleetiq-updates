@echo off
setlocal enabledelayedexpansion
chcp 65001 >nul 2>&1
title Ebsary Fleet IQ - Local AI Setup
cd /d "%~dp0"

echo.
echo ======================================================
echo   EBSARY FLEET IQ - LOCAL AI ENGINE SETUP
echo   Ebsary Foundation Co. - Est. 1922
echo.
echo   This sets up a local AI model on your laptop.
echo   Fleet IQ will scan documents WITHOUT internet or
echo   API costs. Falls back to cloud if needed.
echo ======================================================
echo.

:: -- Check if Ollama is already installed and running -------------------------
where ollama >nul 2>&1
if not errorlevel 1 (
    echo   Ollama is already installed.
    goto :check_model
)

:: Check if already installed but not in PATH
if exist "%LOCALAPPDATA%\Programs\Ollama\ollama.exe" (
    echo   Ollama is already installed.
    set PATH=%PATH%;%LOCALAPPDATA%\Programs\Ollama
    goto :check_model
)

:: -- Download and install Ollama ----------------------------------------------
echo   Downloading Ollama for Windows...
echo   (This is a ~100 MB download - please wait)
echo.

if not exist "%~dp0tools" mkdir "%~dp0tools"

powershell -NoProfile -Command ^
  "Invoke-WebRequest -Uri 'https://ollama.com/download/OllamaSetup.exe' -OutFile '%~dp0tools\OllamaSetup.exe' -UseBasicParsing"

if errorlevel 1 (
    echo.
    echo   ERROR: Could not download Ollama.
    echo   Please download it manually from: https://ollama.com/download
    echo   Install it, then run this script again.
    echo.
    pause
    exit /b 1
)

echo   Installing Ollama (silent install)...
"%~dp0tools\OllamaSetup.exe" /S

:: Wait for install to complete
timeout /t 5 /nobreak >nul

:: Add to PATH for this session
set PATH=%PATH%;%LOCALAPPDATA%\Programs\Ollama

where ollama >nul 2>&1
if errorlevel 1 (
    echo.
    echo   Ollama installed. Please restart this script once to reload PATH.
    echo.
    pause
    exit /b 0
)

echo   Ollama installed successfully.
echo.

:check_model
:: -- Start Ollama service if not running --------------------------------------
echo   Starting Ollama service...
start /min "" ollama serve >nul 2>&1
timeout /t 3 /nobreak >nul

:: -- Check if model is already downloaded -------------------------------------
set MODEL=llama3.2:latest
ollama list 2>nul | findstr /I "llama3.2" >nul 2>&1
if not errorlevel 1 (
    echo   Model already downloaded: %MODEL%
    goto :test_model
)

echo.
echo ======================================================
echo   DOWNLOADING AI MODEL
echo   Model: Llama 3.2 (11B parameters)
echo   Size:  ~7 GB download
echo   This only happens ONCE. Please wait...
echo ======================================================
echo.

ollama pull %MODEL%

if errorlevel 1 (
    echo.
    echo   ERROR: Could not download model.
    echo   Make sure you have internet access and ~8 GB free disk space.
    echo.
    pause
    exit /b 1
)

echo.
echo   Model downloaded successfully.

:test_model
:: -- Run a quick test ---------------------------------------------------------
echo.
echo   Testing local AI engine...
for /f "delims=" %%r in ('ollama run %MODEL% "Reply with exactly: READY" 2^>nul') do (
    set TEST_RESULT=%%r
)

echo   Test result: !TEST_RESULT!
echo.

:: -- Save the selected model to Fleet IQ settings ----------------------------
echo   Configuring Fleet IQ to use local AI...
"%~dp0node\node.exe" -e "
const Database = require('better-sqlite3');
const db = new Database('%~dp0data.db'.replace(/\\\\/g, '/'));
db.prepare(\"INSERT OR REPLACE INTO app_settings (key, value) VALUES ('ai_engine', 'auto')\").run();
db.prepare(\"INSERT OR REPLACE INTO app_settings (key, value) VALUES ('ollama_model', 'llama3.2:latest')\").run();
db.prepare(\"INSERT OR REPLACE INTO app_settings (key, value) VALUES ('ollama_url', 'http://localhost:11434')\").run();
db.close();
console.log('Settings saved.');
" 2>nul

echo.
echo ======================================================
echo   LOCAL AI SETUP COMPLETE
echo.
echo   Fleet IQ is now configured to:
echo     1. Use your laptop's AI first (free, offline)
echo     2. Fall back to cloud (Anthropic) if needed
echo.
echo   You can change this anytime in Fleet IQ Settings.
echo ======================================================
echo.
echo   Press any key to launch Fleet IQ.
echo.
pause

call "%~dp0FleetIQ.bat"

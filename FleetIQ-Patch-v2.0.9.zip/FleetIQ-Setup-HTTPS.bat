@echo off
setlocal enabledelayedexpansion
chcp 65001 >nul 2>&1
title Ebsary Fleet IQ - HTTPS Setup
cd /d "%~dp0"

echo.
echo ======================================================
echo   EBSARY FLEET IQ - SECURE HTTPS SETUP
echo   Ebsary Foundation Co. - Est. 1922
echo   Run this ONCE to enable the green padlock.
echo ======================================================
echo.

:: -- Check if already set up --------------------------------------------------
if exist "%~dp0certs\localhost.crt" (
    echo   HTTPS is already configured on this machine.
    echo   Fleet IQ will use https://localhost:5000
    echo.
    pause
    exit /b 0
)

:: -- Check for mkcert ---------------------------------------------------------
where mkcert >nul 2>&1
if not errorlevel 1 goto :mkcert_found

:: -- Try to download mkcert via winget (Windows 10/11) ------------------------
echo   Installing mkcert (certificate tool)...
winget install --id FiloSottile.mkcert -e --silent >nul 2>&1

:: Reload PATH
set PATH=%PATH%;%LOCALAPPDATA%\Microsoft\WinGet\Packages\FiloSottile.mkcert_Microsoft.Winget.Source_8wekyb3d8bbwe\

where mkcert >nul 2>&1
if not errorlevel 1 goto :mkcert_found

:: -- Fallback: download mkcert binary directly --------------------------------
echo   Downloading mkcert binary...
if not exist "%~dp0tools" mkdir "%~dp0tools"
powershell -NoProfile -Command ^
  "Invoke-WebRequest -Uri 'https://github.com/FiloSottile/mkcert/releases/download/v1.4.4/mkcert-v1.4.4-windows-amd64.exe' -OutFile '%~dp0tools\mkcert.exe' -UseBasicParsing"
if errorlevel 1 (
    echo.
    echo   ERROR: Could not download mkcert. Check your internet connection.
    echo   Or download manually from: https://github.com/FiloSottile/mkcert/releases
    echo   Place mkcert.exe in: %~dp0tools\
    echo   Then run this script again.
    echo.
    pause
    exit /b 1
)
set MKCERT_EXE=%~dp0tools\mkcert.exe
goto :generate

:mkcert_found
set MKCERT_EXE=mkcert

:generate
:: -- Install root CA into Windows + Chrome trust store -----------------------
echo.
echo   Installing trusted certificate authority...
echo   (Windows may ask for permission - click YES)
echo.
"%MKCERT_EXE%" -install

if errorlevel 1 (
    echo.
    echo   ERROR: Could not install certificate authority.
    echo   Try right-clicking FleetIQ-Setup-HTTPS.bat and selecting
    echo   "Run as administrator", then try again.
    echo.
    pause
    exit /b 1
)

:: -- Generate localhost certificate -------------------------------------------
echo.
echo   Generating certificate for localhost...
if not exist "%~dp0certs" mkdir "%~dp0certs"

"%MKCERT_EXE%" -key-file "%~dp0certs\localhost.key" -cert-file "%~dp0certs\localhost.crt" localhost 127.0.0.1 ::1

if errorlevel 1 (
    echo.
    echo   ERROR: Certificate generation failed.
    echo.
    pause
    exit /b 1
)

echo.
echo ======================================================
echo   HTTPS SETUP COMPLETE
echo.
echo   Fleet IQ will now run at:
echo   https://localhost:5000
echo.
echo   Chrome, Edge, and all browsers will show the
echo   green padlock with no warnings.
echo.
echo   You only need to run this ONCE per machine.
echo ======================================================
echo.
echo   Press any key to launch Fleet IQ now.
echo.
pause

call "%~dp0FleetIQ.bat"
